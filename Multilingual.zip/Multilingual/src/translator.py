from googletrans import Translator

class TranslationService:
    def __init__(self):
        self.languages = self.load_languages()
        self.translator = Translator()

    def load_languages(self):
        return {
            'en': 'English',
            'fr': 'French',
            'es': 'Spanish',
            'de': 'German',
            'it': 'Italian',
            'nl': 'Dutch',
            'pt': 'Portuguese'
        }    

    def detect_language(self, text):
        result = self.translator.detect(text)
        
        detected_code = result.lang 
        detected_name = self.languages.get(detected_code, 'Unknown')

        return {'code': detected_code, 'name': detected_name}

    def get_available_languages(self):
        return [{'code': code, 'name': name} for code, name in self.languages.items()]
